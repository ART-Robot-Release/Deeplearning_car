#coding=utf8
"""
File: models.py
Author: liujinhui
Time: 2019/11/05
"""
import os
import json
from typing import Optional, Awaitable
import file_util
from models import Models
from config import Config
import importlib
import sys
import time
importlib.reload(sys)

class Cameras(object):
    """
    摄像头管理类
    """ 
    
    def __init__(self):
        """
        初始化
        :return:
        """ 
        pass

    def cameras_list(self):
        """
        摄像头列表
        :return:
        """ 
        content = file_util.read_file(Config.camera_path) 
        return content
        
    def get_camera(self, s_id):  
        """
        获取摄像头
        :param s_id, id
        :return:
        """ 
        content = file_util.read_file(Config.camera_path)
        if content is None:
            return content
        else:
            data_json = json.loads(content)
            camera_list = data_json['cameras']
            s_content = None
            for it in camera_list:
                if int(s_id) == int(it['id']):
                    s_content = it
                    break
            return s_content

    def put_camera(self, new_data, s_id):
        """
        更新摄像头
        : new_data 新模型内容
        :param s_id, id
        :return:
        """
        content = file_util.read_file(Config.camera_path)
        if content is None:
            return content
        else:
            data_json = json.loads(content)
            camera_list = data_json['cameras']
            if s_id.isdigit():
                arr =[]
                for it in camera_list:
                    if int(s_id) == int(it['id']):
                        new_data_json = json.loads(new_data)
                        tmp_json = {}
                        tmp_json['id'] = int(s_id)
                        tmp_json['name'] = new_data_json['name']
                        tmp_json['type'] = new_data_json['type']
                        tmp_json['path'] = new_data_json['path']
                        tmp_json['sn_code'] = new_data_json['sn_code']
                        tmp_json['time_add'] = new_data_json['time_add']
                        tmp_json['comments'] = new_data_json['comments']
                        arr.append(tmp_json)
                    else:
                        arr.append(it)
                       
                content_json = {"cameras":arr}
                serialization=json.dumps(content_json, indent = 4).encode("utf-8")
                file_util.save_file(serialization, Config.camera_path) 
                return new_data
            else:
                return None
        return None

    def patch_camera(self, new_data, s_id):
        """
        更新摄像头
        : new_data 新摄像头数据
        :param s_id, id
        :return:
        """
        content = file_util.read_file(Config.camera_path)
        if content is None:
            return content
        else:
            data_json = json.loads(content)
            camera_list = data_json['cameras']
            new_data_json = json.loads(new_data)
            if s_id.isdigit():
                arr =[]
                for it in camera_list:
                    if int(s_id) == int(it['id']):  
                        tmp_json = {}
                        tmp_json['id'] = int(s_id)      
                        if "name" not in new_data_json:
                            tmp_json['name'] = it['name']
                        else:
                            tmp_json['name'] = new_data_json['name']
                        if "type" not in new_data_json:
                            tmp_json['type'] = it['type']
                        else:
                            tmp_json['type'] = new_data_json['type']
                        if "path" not in new_data_json:
                            tmp_json['path'] = it['path'] 
                        else:
                            tmp_json['path'] = new_data_json['path']

                        if "sn" not in new_data_json:
                            tmp_json['sn_code'] = it['sn_code'] 
                        else:
                            tmp_json['sn_code'] = new_data_json['sn_code']

                        if "time_add" not in new_data_json:
                            tmp_json['time_add'] = it['time_add']
                        else:
                            tmp_json['time_add'] = new_data_json['time_add']
                        if "comments" not in new_data_json:
                            tmp_json['comments'] = it['comments']
                        else:
                            tmp_json['comments'] = new_data_json['comments']
                    
                        arr.append(tmp_json)
                    else:
                        arr.append(it)
                       
                content_json = {"cameras":arr}
                serialization=json.dumps(content_json, indent = 4).encode("utf-8")
                file_util.save_file(serialization, Config.camera_path) 
                return new_data_json
            else:
                return None
        return None

    def delete_camera(self, s_id):
        """
        删除摄像头
        :param s_id, id
        :return:
        """
        content = file_util.read_file(Config.camera_path)
        if content is None:
            return content
        else:
            data_json = json.loads(content)
            camera_list = data_json['cameras']
            new_data_json = []
            if s_id.isdigit():
                arr =[]
                for it in camera_list:
                    if int(s_id) == int(it['id']):                        
                        new_data_json = it
                    else:
                        arr.append(it)
                       
                content_json = {"cameras":arr}
                serialization=json.dumps(content_json, indent = 4).encode("utf-8")
                file_util.save_file(serialization, Config.camera_path) 
                self.delete_camera_collections(s_id)
                return new_data_json
            else:
                return None
        return None

    def delete_camera_collections(self, camera_id):
        """
        删除采集管理里关联的摄像头
        :param camera_id
        :return:
        """
        content = file_util.read_file(Config.collection_path) 
        if content is None:
            return 
        content_json = json.loads(content)
        coll_arr = content_json['collections']
        if len(coll_arr):
            new_arr = []
            exist = False
            for jt in coll_arr:
                if int(camera_id) == int(jt['device_id']):
                    exist = True
                else:
                    new_arr.append(jt)
            if exist:
                if len(new_arr):
                    content_json = {"collections":new_arr}
                    serialization=json.dumps(content_json, indent = 4).encode("utf-8")
                    file_util.save_file(serialization, Config.collection_path) 
                else:
                    file_util.delete_file(Config.collection_path)
                
    def check_id_exist(self, s_id):
        """
        判断id是否存在
        :param s_id, id
        :return:
        """
        res = False
        content = file_util.read_file(Config.camera_path)
        if content is None:
            return res
        else:
            data_json = json.loads(content)
            camera_list = data_json['cameras']
            for it in camera_list:
                if int(s_id) == int(it['id']):
                    res = True
            return res

    def get_device_name(self, camera_id):
        """
        根据camera_id获取设备名称
        :param camera_id
        :return:
        """
        content = file_util.read_file(Config.camera_path)
        if content is None:
            return None
        data_json = json.loads(content)
        camera_list = data_json['cameras']
        for it in camera_list:
            if int(camera_id) == int(it['id']):
                return it['name']
        return None


    def gen_camera_id(self, content):
        """
        获取摄像头id
        :param content, 内容
        :return:
        """
        arr =[]
        for it in content:
            id = int(it['id'])
            arr.append(id)
        index = 0
        while index in arr:
            index += 1       
        return index

    def check_item(self, content):
        """
        判断是否存在
        :param content, 内容
        :return:
        """
        res = False
        if "name" not in content:
                 res = False
        else:
            res = True
        return res

    def create_camera(self, json_data):
        """
        创建摄像头
        :param json_data, 内容
        :return:
        """
        content = file_util.read_file(Config.camera_path)
        data_json = {}
        id = 0
        print("content is:")
        print(content)
        if content is None:              
            data_json['id'] = id
            data_json['name'] = json_data['name']
            data_json['type'] = json_data['type']
            data_json['path'] = json_data['path']
            data_json['sn_code'] = json_data['sn_code']
            data_json['time_add'] = json_data['time_add']
            data_json['comments'] = json_data['comments']
            json_arr = []
            json_arr.append(data_json)
            cameras_content = {"cameras": json_arr}
            serialization=json.dumps(cameras_content, indent = 4).encode("utf-8")
            file_util.save_file(serialization, Config.camera_path) 
        else:
            content_json = json.loads(content)
            arr = content_json['cameras']
            id = self.gen_camera_id(arr)  
            data_json['id']=id  
            data_json['name'] = json_data['name']
            data_json['type'] = json_data['type']
            data_json['path'] = json_data['path']
            data_json['sn_code'] = json_data['sn_code']
            data_json['time_add'] = json_data['time_add']
            data_json['comments'] = json_data['comments']
            json_arr = []
            for jt in arr:
                if isinstance(jt, dict):
                    json_arr.append(jt)
                 
            json_arr.append(data_json)
            cameras_content = {"cameras": json_arr}
            serialization=json.dumps(cameras_content, indent = 4).encode("utf-8")
            file_util.save_file(serialization, Config.camera_path)   
              
        return id

    def create_camera_setting(self, json_data, camera_id):
        """
        提交摄像头设置信息
        :param json_data, 内容
        :return:
        """
        data_json = json.loads(json_data)
        setting_arr = data_json['sorted_models']
        mgr = Models()
        #判断是否有模型id不在模型列表中，如有，则直接返回出错
        json_arr = []
        for jt in setting_arr:
            model_id = jt['model_id']
            exist = mgr.check_id_exist(model_id)
            if exist is False:
                return None
            tmp = {}
            tmp['enable'] = jt['enable']
            tmp['model'] = mgr.get_model(model_id)
            tmp['seconds'] = jt['seconds']
            tmp['frames'] = jt['frames']
            json_arr.append(tmp)

        if len(json_arr) is False:
            return None

        #判断模型id是否已在设置列表中
        old_content = file_util.read_file(Config.camera_setting_path)
        #原保存为空
        if old_content  is None:
            data_json = {}
            data_json['id'] = int(camera_id)
            data_json['sorted_models'] = json_arr 
            serialization = json.dumps(data_json, indent = 4) 
            new_save = {}
            save_arr = []
            save_arr.append(data_json)
            new_save['setting'] = save_arr
            file_util.save_file(json.dumps(new_save, indent = 4).encode("utf-8"), Config.camera_setting_path)  
            return serialization 
        #原保存文件不为空
        else:
            old_json = json.loads(old_content)
            old_arr = old_json['setting']
            data_json = {}
            data_json['id'] = int(camera_id)
            data_json['sorted_models'] = json_arr 
            new_save = {}
            #原保存数据为空
            if len(old_arr) is False:
                save_arr = []
                save_arr.append(data_json)
                new_save['setting'] = save_arr
            else:
                exist = False
                for it in old_arr:
                    if int(camera_id) == int(it['id']): 
                        exist = True

                #若该camera_id不存在，则需要新增保存
                save_arr = []
                if exist is False:       
                    for it in old_arr:
                        save_arr.append(it)
                    save_arr.append(data_json)
                #若存在，则需替换
                else:
                    for it in old_arr:
                        #找到了旧的camer_id，需替换
                        if int(camera_id) == int(it['id']): 
                            save_arr.append(data_json)
                        else:
                            save_arr.append(it)  

                new_save['setting'] = save_arr
            file_util.save_file(json.dumps(new_save, indent = 4).encode("utf-8"), Config.camera_setting_path)        
            serialization = json.dumps(data_json, indent = 4)    
            return serialization 

    def get_camera_setting(self, s_id):
        """
        获取摄像头设置信息
        :param s_id,摄像头id
        :return:
        """
        #先判断id是否在摄像头列表中，若不在，返回None
        id_exist = Cameras.check_id_exist(self, s_id)  
        if id_exist is False:
            return None 

        setting_content = file_util.read_file(Config.camera_setting_path)
        setting_json = {}
        models_content = file_util.read_file(Config.model_path)
        #模型文件不存在
        if models_content is None:
            if file_util.is_file_exist(Config.camera_setting_path):
                file_util.delete_file(Config.camera_setting_path)
            return None
        #模型文件存在但列表为空
        data_json = json.loads(models_content)
        if len(data_json) is None:
            return None

        #假如之前无设置内容
        if setting_content is None: 
            #补全models里面的
            models_json = data_json['models']
            setting_model_arr =[]
            for jt in models_json:
                tmp ={}
                tmp['enable'] = False
                tmp['model'] = jt
                tmp['seconds'] = 0
                tmp['frames'] = 0
                setting_model_arr.append(tmp)
            setting_json['id'] = s_id
            setting_json['sorted_models'] = setting_model_arr
        else:
            old_json = json.loads(setting_content)
            setting_arr = old_json['setting']
            if len(setting_arr) is False:
                #补全models里面的
                models_json = data_json['models']
                setting_model_arr =[]
                for jt in models_json:
                    tmp ={}
                    tmp['enable'] = False
                    tmp['model'] = jt
                    tmp['seconds'] = 0
                    tmp['frames'] = 0
                    setting_model_arr.append(tmp)
                setting_json['id'] = s_id
                setting_json['sorted_models'] = setting_model_arr
            else:
                exist_old = False
                for a_it in setting_arr:
                    #找到了camera_id
                    if int(a_it['id']) == int(s_id):
                        exist_old = True
                        print("find it ")
                        old_model_arr = a_it['sorted_models']
                        old_model_id_arr = []
                        for o_it in old_model_arr:
                            old_model_id_arr.append(int(o_it['model']['id']))

                        print("old_model_id_arr is:")
                        print(old_model_id_arr)

                        #补全models里面的
                        models_json = data_json['models']
                        setting_model_arr =[]
                        for jt in models_json:
                            tmp ={}
                            tmp['enable'] = False
                            tmp['model'] = jt
                            tmp['seconds'] = 0
                            tmp['frames'] = 0
                            m_id = int(jt['id'])
                            if m_id in old_model_id_arr:
                                pass
                            else:
                                old_model_arr.append(tmp)
                        setting_json['id'] = s_id
                        setting_json['sorted_models'] = old_model_arr

                if exist_old is False:
                    #没找到旧设置
                    print("not found")
                     #补全models里面的
                    models_json = data_json['models']
                    model_arr = []
                    for jt in models_json:
                        tmp ={}
                        tmp['enable'] = False
                        tmp['model'] = jt
                        tmp['seconds'] = 0
                        tmp['frames'] = 0
                        model_arr.append(tmp)
                    setting_json['id'] = s_id
                    setting_json['sorted_models'] = model_arr
                    
        return setting_json
    def get_prev_model_id(self, camera_id):
        """
        get model id
        :param camera_id
        :return:
        """
        model_id_arr = []
        id_exist = Cameras.check_id_exist(self, camera_id)
        if id_exist is False:
            return model_id_arr

        setting_content = file_util.read_file(Config.camera_setting_path)
        setting_json = {}
        models_content = file_util.read_file(Config.model_path)
        if models_content is None:
            return model_id_arr
        models_json = json.loads(models_content)
        #print(models_json['models'][0]['name'])
        if len(models_json) is None:
            return model_id_arr

        if setting_content is None:
            return model_id_arr

        old_json = json.loads(setting_content)
        setting_arr = old_json['setting']
        if len(setting_arr):
            for sort_models_arr in setting_arr:
                if int(sort_models_arr['id']) == int(camera_id):
                    models_arr = sort_models_arr['sorted_models']
                    if len(models_arr):
                        for arr in models_arr:
                            if arr['enable'] is True:
                                model_id_arr.append(int(arr['model']['id']))     
        return model_id_arr

    def copy_image_from_aiworker(self, s_id, model_id, del_old):
        """
        从aiworker拷贝图片
        :param s_id,摄像头id
        :return:
        """
        model_id_arr = self.get_prev_model_id(s_id)
        print("model_id_arr is:")
        print(model_id_arr)
        ok = False
        old_root_path = os.path.normpath(
                    os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..', 'processes/images'))
        old_path = old_root_path + "/" + str(s_id) + ".jpg"
        new_root_path = os.path.normpath(
                    os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..', 'repository/images'))
        file_util.create_dir(new_root_path)
        new_path = new_root_path + "/" + str(s_id) + ".jpg"
        if del_old:
            file_util.delete_file(new_path)
        file_util.copy_file(old_path, new_path)
        if file_util.is_file_exist(new_path):
            ok = True
        return ok      

    def get_pre_image_path(self, root_path, camera_id, model_id):
        """
        获取预览图片地址
        :param s_id,摄像头id,模型id
        :return:
        """
        pre_file = None
        record_file = root_path + "/" + str(camera_id) + "/" + str(model_id) + "/record"
        if file_util.is_file_exist(record_file):
            pre_file = file_util.read_file(record_file)
            pre_file = pre_file.strip()
            pre_file = pre_file.strip('\n')

        if pre_file is not None and file_util.is_file_exist(pre_file):
            return pre_file
        else:
            return None

    def get_model_name_by_id(self, model_id):
        """
        获取模型名称
        :param s_id,模型id
        :return:
        """
        content = file_util.read_file(Config.model_path)
        if content is None:
            return content
        else:
            data_json = json.loads(content)
            model_list = data_json['models']
            s_content = None
            for it in model_list:
                if int(model_id) == int(it['id']):
                    s_content = it['name']
                    break
            return s_content

    def get_camera_monitor(self, s_id, s_host_ip):
        """
        获取摄像头监控信息
        :param s_id,摄像头id
        :return:
        """
        #先判断id是否在摄像头列表中，若不在，返回None
        id_exist = Cameras.check_id_exist(self, s_id)  
        if id_exist is False:
            return None 

        print("in get_camera_monitor")
        model_id_arr = self.get_prev_model_id(s_id)
        #ok = self.copy_image_from_aiworker(s_id, True)
        #ok = False
        monitor_json = {}
        monitor_json['camera_id'] = s_id
        data_arr = [] 
        if len(model_id_arr):  
            for m_id in model_id_arr:
                arr = {}
                model_name = self.get_model_name_by_id(int(m_id))
                arr['model_id'] = int(m_id)
                arr['model_name'] = model_name
                arr['monitoring'] = "http://" + str(s_host_ip) + "/api/monitoring/result/images/" \
                    + str(s_id) + "/" + str(m_id) + ".jpg" + "?t=" + str(time.time())
                data_arr.append(arr)            
        else:
            pass
        monitor_json['data'] = data_arr
        return monitor_json

    def get_camera_status(self, s_id):
        """
        获取摄像头工作状态信息
        :param s_id,摄像头id
        :return:
        """
        #先判断id是否在摄像头列表中，若不在，返回None
        id_exist = Cameras.check_id_exist(self, s_id)  
        if id_exist is False:
            return None 

        status_content = file_util.read_file(Config.camera_status_path)
        status_json = {}
        status_json['id'] = s_id
        #状态设置文件不存在、默认打开
        if status_content is None:  
            status_json['status'] = "open"
        else: 
            json_content = json.loads(status_content)
            status_arr = json_content['camera_status']
            exist = False
            for jt in status_arr:
                j_id = jt['id']
                if int(s_id) == int(j_id):
                    status_json['status'] = jt['status']
                    exist = True
            #如果没保存，则值为打开
            if exist is False:
                status_json['status'] = "open"

        return status_json 
        
    def set_camera_status(self, s_id, post_data):
        """
        设置摄像头打开或关闭
        :param s_id,摄像头id
        :return:
        """
        #先判断id是否在摄像头列表中，若不在，返回None
        id_exist = Cameras.check_id_exist(self, s_id)  
        if id_exist is False:
            return None 

        json_data = json.loads(post_data)
        action = json_data['action']
        s_open = "open"
        result = {}
        result['id'] = s_id
        result['status'] = action 
        if json_data is None:
            return result

        status_content = file_util.read_file(Config.camera_status_path)

        if action == s_open:
            #若为open状态，且老数据为close状态，需修改，其他情况可忽略不做任何操作
            if status_content is not None:
                json_content = json.loads(status_content)
                status_arr = json_content['camera_status'] 
                json_arr = []
                for jt in status_arr: 
                    if int(s_id) != int(jt['id']):
                        json_arr.append(jt)

                s_content = {"camera_status": json_arr}
                serialization=json.dumps(s_content, indent = 4).encode("utf-8")
                file_util.save_file(serialization, Config.camera_status_path)       
        else:
            #之前状态文件为空，需新写入
            if  status_content is None:
                json_arr = []
                tmp = {}
                tmp['id'] = s_id
                tmp['status'] = "close"
                json_arr.append(tmp)
                s_content = {"camera_status": json_arr}
                serialization=json.dumps(s_content, indent = 4).encode("utf-8")
                file_util.save_file(serialization, Config.camera_status_path)
            #之前状态文件不为空，需增加写入
            else:
                json_content = json.loads(status_content)
                status_arr = json_content['camera_status'] 
                json_arr = []
                for jt in status_arr: 
                    if int(s_id) != int(jt['id']):
                        json_arr.append(jt)

                tmp = {}
                tmp['id'] = s_id
                tmp['status'] = "close"
                json_arr.append(tmp)
                s_content = {"camera_status": json_arr}
                serialization=json.dumps(s_content, indent = 4).encode("utf-8")
                file_util.save_file(serialization, Config.camera_status_path)
        return result



    


    

       
        

        

            
        
        



    
            


        
        



   



