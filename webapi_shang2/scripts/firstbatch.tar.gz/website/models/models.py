#coding=utf8
"""
File: models.py
Author: liujinhui
Time: 2019/10/25
"""
import os
import re
import json
import shutil
import mimetypes
import zipfile
import tarfile
from typing import Optional, Awaitable
import file_util
from config import Config
from settings import folder_web_cache

class Models(object):
    """
    模型类
    """ 
    
    def __init__(self):
        """
        初始化
        :return:
        """ 
        pass

    def models_list(self):
        """
        模型列表
        :return:
        """ 
        content = file_util.read_file(Config.model_path) 
        return content
        
    def get_model(self, s_id):  
        """
        获取模型
        :param s_id, id
        :return:
        """ 
        content = file_util.read_file(Config.model_path)
        if content is None:
            return content
        else:
            data_json = json.loads(content)
            model_list = data_json['models']
            s_content = None
            for it in model_list:
                if int(s_id) == int(it['id']):
                    s_content = it
                    break
            return s_content

    def put_model(self, new_data, s_id):
        """
        更新模型
        : new_data 新模型内容
        :param s_id, id
        :return:
        """
        content = file_util.read_file(Config.model_path)
        if content is None:
            return content
        else:
            data_json = json.loads(content)
            model_list = data_json['models']
            if s_id.isdigit():
                arr =[]
                for it in model_list:
                    if int(s_id) == int(it['id']):
                        new_data_json = json.loads(new_data)
                        tmp_json = {}
                        tmp_json['id'] = int(s_id)
                        tmp_json['name'] = new_data_json['name']
                        tmp_json['enable'] = new_data_json['enable']
                        tmp_json['type'] = new_data_json['type']
                        tmp_json['license'] = new_data_json['license']  
                         
                        print("put model begin:")
                        self.copy_model_file(new_data_json['file'], int(s_id))
                        new_url = self.gen_model_file_uri(new_data_json['file'], int(s_id))
                        tmp_json['file'] = new_url

                        tmp_json['callback'] = new_data_json['callback']
                        tmp_json['time'] = new_data_json['time']
                        tmp_json['comments'] = new_data_json['comments']
                        tmp_json['tf'] = new_data_json['tf']
                        arr.append(tmp_json)
                    else:
                        arr.append(it)
                       
                content_json = {"models":arr}
                
                serialization=json.dumps(content_json, indent = 4).encode("utf-8")
                file_util.save_file(serialization, Config.model_path) 
                return new_data
            else:
                return None
        return None

    def patch_model(self, new_data, s_id):
        """
        更新模型
        : new_data 新模型内容
        :param s_id, id
        :return:
        """
        content = file_util.read_file(Config.model_path)
        if content is None:
            return content
        else:
            data_json = json.loads(content)
            model_list = data_json['models']
            new_data_json = json.loads(new_data)
            if s_id.isdigit():
                arr =[]
                for it in model_list:
                    if int(s_id) == int(it['id']):  
                        tmp_json = {}
                        tmp_json['id'] = int(s_id)   
                        if "name" not in new_data_json:
                            tmp_json['name'] = it['name']
                        else:
                            tmp_json['name'] = new_data_json['name']

                        if "enable" not in new_data_json:
                            tmp_json['enable'] = it['enable']
                        else:
                            tmp_json['enable'] = new_data_json['enable']

                        if "type" not in new_data_json:
                            tmp_json['type'] = it['type']
                        else:
                            tmp_json['type'] = new_data_json['type']

                        if "license" not in new_data_json:
                            tmp_json['license'] = it['license']
                        else:
                            tmp_json['license'] = new_data_json['license']

                        if "file" not in new_data_json:
                            tmp_json['file'] = it['file']
                        else:
                            tmp_json['file'] = new_data_json['file']

                        if "callback" not in new_data_json:
                            tmp_json['callback'] = it['callback']
                        else:
                            tmp_json['callback'] = new_data_json['callback']

                        if "time" not in new_data_json:
                            tmp_json['time'] = it['time']
                        else:
                            tmp_json['time'] = new_data_json['time']

                        if "comments" not in new_data_json:
                            tmp_json['comments'] = it['comments']
                        else:
                            tmp_json['comments'] = new_data_json['comments']

                        if "tf" not in new_data_json:
                            tmp_json['tf'] = it['tf']
                        else:
                            tmp_json['tf'] = new_data_json['tf']
                                
                        arr.append(tmp_json)
                    else:
                        arr.append(it)
                       
                content_json = {"models":arr}
                serialization=json.dumps(content_json, indent = 4).encode("utf-8")
                file_util.save_file(serialization, Config.model_path) 
                return new_data_json
            else:
                return None
        return None

    def delete_model(self, model_id):
        """
        删除模型
        :param s_id, id
        :return:
        """
        content = file_util.read_file(Config.model_path)
        if content is None:
            return content
        else:
            data_json = json.loads(content)
            model_list = data_json['models']
            new_data_json = []
            if model_id.isdigit():
                arr =[]
                for it in model_list:
                    if int(model_id) == int(it['id']):                        
                        new_data_json = it
                    else:
                        arr.append(it)
                       
                content_json = {"models":arr}
                serialization=json.dumps(content_json, indent = 4).encode("utf-8")
                file_util.save_file(serialization, Config.model_path) 
                #删除摄像头里面的关联模型
                self.delete_cameras_model(model_id)
                #删除模型文件
                self.delete_model_file(model_id)
                return new_data_json
            else:
                return None
        return None

    def delete_model_file(self, model_id):
        """
        删除模型文件
        :param model_id
        :return:
        """
        root_path = os.path.normpath(
                    os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..', 'repository/models'))
        model_id_path = root_path + '/' + str(model_id) + '/'
        file_util.delete_folder(model_id_path)

    def delete_model_file_json(self, model_id):
        """
        删除json中的模型文件路径
        :param model_id
        :return:
        """
        content = file_util.read_file(Config.model_path)
        if content is None:
            pass
        else:
            data_json = json.loads(content)
            model_list = data_json['models']
            s_content = None
            for it in model_list:
                if int(model_id) == int(it['id']):
                    it['file']=""

            content_json = {"models":model_list}    
            serialization=json.dumps(content_json, indent = 4).encode("utf-8")
            file_util.save_file(serialization, Config.model_path) 

    def delete_cameras_model(self, model_id):
        """
        删除摄像头关联模型
        :param model_id
        :return:
        """
        content = file_util.read_file(Config.camera_setting_path)
        if content is not None:

            old_json = json.loads(content)
            setting_arr = old_json['setting']
            new_arr = []
            if len(setting_arr):
                for jt in setting_arr:
                    sub_arr = jt['sorted_models']
                    new_sub_arr = []
                    if len(sub_arr):
                        for s_jt in sub_arr:
                            s_model = s_jt['model']
                            if int(model_id) == int(s_model['id']):
                                pass
                            else:
                                new_sub_arr.append(s_jt)

                    if len(new_sub_arr):
                        new_item = {}
                        new_item['id'] = jt['id']
                        new_item['sorted_models'] = new_sub_arr
                        new_arr.append(new_item)

            if len(new_arr):
                content_json = {"setting":new_arr}
                serialization=json.dumps(content_json, indent = 4).encode("utf-8")
                file_util.save_file(serialization, Config.camera_setting_path) 
            else:
                file_util.delete_file(Config.camera_setting_path)


    def check_id_exist(self, s_id):
        """
        判断id是否存在
        :param s_id, id
        :return:
        """
        res = False
        content = file_util.read_file(Config.model_path)
        if content is None:
            return res
        else:
            data_json = json.loads(content)
            model_list = data_json['models']
            for it in model_list:
                if int(s_id) == int(it['id']):
                    res = True
            return res

    def gen_model_id(self, content):
        """
        获取模型id
        :param content, 内容
        :return:
        """
        arr =[]
        for it in content:
            id = int(it['id'])
            arr.append(id)
        index = 0
        while index in arr:
            index += 1       
        return index

    def check_item(self, content):
        """
        判断是否存在
        :param content, 内容
        :return:
        """
        res = False
        if "name" not in content:
                 res = False
        else:
            res = True
        return res

    def create_model(self, json_data):
            """
            创建模型
            :param json_data, 内容
            :return:
            """
            content = file_util.read_file(Config.model_path)
            data_json = {}
            id = 0
            if content is None:              
                data_json['id'] = id
                data_json['name'] = json_data['name']
                data_json['enable'] = json_data['enable']
                data_json['type'] = json_data['type']
                data_json['license'] = json_data['license']
                self.copy_model_file(json_data['file'], id)
                new_url = self.gen_model_file_uri(json_data['file'], id)
                data_json['file'] = new_url
                data_json['callback'] = json_data['callback']
                data_json['time'] = json_data['time']
                data_json['comments'] = json_data['comments']
                data_json['tf'] = json_data['tf']
                json_arr = []
                json_arr.append(data_json)
                models_content = {"models": json_arr}
                serialization=json.dumps(models_content, indent = 4).encode("utf-8")
                file_util.save_file(serialization, Config.model_path)                 
            else:
                content_json = json.loads(content)
                arr = content_json['models']
                id = self.gen_model_id(arr)  
                data_json['id']=id  
                data_json['name'] = json_data['name']
                data_json['enable'] = json_data['enable']
                data_json['type'] = json_data['type']
                data_json['license'] = json_data['license']
                self.copy_model_file(json_data['file'], id) 
                new_url = self.gen_model_file_uri(json_data['file'], id)
                data_json['file'] = new_url
                data_json['callback'] = json_data['callback']
                data_json['time'] = json_data['time']
                data_json['comments'] = json_data['comments']
                data_json['tf'] = json_data['tf']
                json_arr = []
                for jt in arr:
                    if isinstance(jt, dict):
                        json_arr.append(jt)       
                json_arr.append(data_json)
                models_content = {"models": json_arr}
                serialization=json.dumps(models_content, indent = 4).encode("utf-8")
                file_util.save_file(serialization, Config.model_path)           
            return id

    def gen_model_tmp_path(self):
        """
        生成模型临时文件夹路径
        :return:
        """ 
        # del old folder files
        tmp_dir = os.path.normpath(
                       os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..', 'repository/tmp-models'))
        #file_util.delete_folder(tmp_dir)
        file_util.create_dir(tmp_dir)
        return tmp_dir

    def copy_model_file(self, model_url, model_id):
        """
        模型文件放置到正确位置
        :param json_data, 内容
        :return:
        """ 
        #模型路径为空时候，直接返回
        if model_url == "":
            return 
        #模型路径本来就在模型id下面时候，直接返回
        pos = model_url.find('uploaded')
        if pos < 0:
            return
        else:
            uri_len = len(model_url)
            sub_uri = model_url[pos + 9: uri_len]
            id_pos = sub_uri.find('/')
            #不带模型id，需要移动模型文件放入正确位置
            if id_pos < 0:
                #创建模型文件根目录:
                root_path = os.path.normpath(
                    os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..', 'repository/models'))
                file_util.create_dir(root_path)
                s_model_id = str(model_id)
                model_id_path = root_path + '/' + s_model_id + '/'
                file_util.delete_folder(model_id_path)
                file_util.create_dir(model_id_path)
                filename = file_util.get_filename(model_url)
                tmp_dir = os.path.normpath(
                       os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..', 'repository/tmp-models'))
                file_path = tmp_dir + "/" + filename
                file_util.move_file(file_path, model_id_path)

    def gen_model_file_uri(self, model_url, model_id):
        """
        生成新的模型文件url
        :model_url老的模型文件url地址
        :model_id模型文件id
        :return:
        """ 
        if model_url == "":
            return model_url

        #模型路径本来就在模型id下面时候，直接返回
        pos = model_url.find('uploaded')
        if pos < 0:
            return model_url
        else:
            uri_len = len(model_url)
            sub_uri = model_url[pos + 9: uri_len]
            id_pos = sub_uri.find('/')
            #不带模型id，需要生成新的模型文件url
            if id_pos < 0:
                name = file_util.get_filename(model_url)
                pos = model_url.rfind('/')
                url_len = len(model_url)
                pre_url = model_url[0:pos]
                new_model_url = pre_url + "/" + str(model_id) + "/" + name
                return new_model_url
            else:
                return model_url

    def check_upload_model(self, file_path):
        """
        校验上传的模型文件
        :file_path 模型文件路径
        :return: 
        """ 
        file_type = mimetypes.guess_type(file_path)[0]
        f_type = 0
        ok = False
        if file_type == "application/x-tar":
            ok = True
            f_type = 1
        elif file_type == "application/zip":
            ok = True
            f_type = 2
        else:
            f_type=0
        
        if f_type <= 0:
            return ok
        
        find_params = False
        find_model = False
        find_json = False   
        find_label = False  
        count = 0
        #tar file
        if f_type == 1:
            t_model_pattern = r"(.*)/model/model$"
            t_params_pattern =r"(.*)/model/params$"
            t_laber_pattern = r"(.*)/model/label_list.txt$"
            t_json_pattern = r"(.*)/config/config.json$"

            tfile = tarfile.open(file_path, 'r')
            for filename in tfile.getnames():
                find_m = re.match(t_model_pattern, filename)
                find_p = re.match(t_params_pattern, filename)
                find_l = re.match(t_laber_pattern, filename)
                find_j = re.match(t_json_pattern, filename)
                if find_m:
                    find_model = True
                if find_p:
                    find_params = True
                if find_l:
                    find_label = True
                if find_j:
                    find_json = True
            if find_params and find_model and find_label and find_json:
                ok = True
            else:
                ok = False
        #zip file
        elif f_type == 2:
            z_model_pattern = r"(.*)/model/model$"
            z_params_pattern = r"(.*)/model/params$"
            z_label_pattern = r"(.*)/model/label_list.txt$"
            z_json_pattern = r"(.*)/config/config.json$"
            zfile = zipfile.ZipFile(file_path, 'r')
            for filename in zfile.namelist():
                find_m = re.match(z_model_pattern, filename)
                find_p = re.match(z_params_pattern, filename)
                find_l = re.match(z_label_pattern, filename)
                find_j = re.match(z_json_pattern, filename)
                if find_m:
                    find_model = True
                if find_p:
                    find_params = True
                if find_l:
                    find_label = True
                if find_j:
                    find_json = True  
            if find_params and find_model and find_label and find_json:
                ok = True
            else:
                ok = False  
            #maybe easydl model,so check easydl
            if ok is False:
                z_model_pattern = r"RES/model$"
                z_params_pattern = r"RES/params$"
                z_conf_pattern = r"RES/conf.json$"
                z_label_pattern = r"RES/label_list.txt$"
                z_progress_pattern = r"RES/preprocess_args.json$"
                find_m = False
                find_p = False
                find_c = False
                find_l = False
                find_pr = False
                for filename in zfile.namelist():
                    print("filename is:")
                    print(filename)
                    f1 = re.match(z_model_pattern, filename)
                    f2 = re.match(z_params_pattern, filename)
                    f3 = re.match(z_conf_pattern, filename)
                    f4 = re.match(z_label_pattern, filename)
                    f5 = re.match(z_progress_pattern, filename)
                    if f1:
                        find_m = True
                    if f2:
                        find_p = True
                    if f3:
                        find_c = True
                    if f4:
                        find_l = True
                    if f5:
                        find_pr = True
                if find_m and find_p and find_c and find_l and find_pr:
                    ok = True
                else:
                    ok = False

        else:
            pass

        return ok
        


       

    
            


        
        



   



