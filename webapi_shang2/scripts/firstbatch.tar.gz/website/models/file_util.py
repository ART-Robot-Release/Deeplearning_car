#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
File: file_util.py
Author: liujinhui
Time: 2019/10/25
"""
import os
import shutil
import traceback
import mimetypes

def save_file(content, file_path, mode='wb+'):
    """
    将内容保存到文件
    :param content: string, 内容
    :param file_path: 文件路径
    :param mode: 写入模式
    :return:
    """
    case_dir = os.path.dirname(file_path)
    if not os.path.exists(case_dir):
        os.makedirs(case_dir)
    try:
        with open(file_path, mode) as writer:
            writer.write(content)
    except Exception as e:
        msg = [
            'Save file fail: %s' % file_path,
            traceback.format_exc()
        ]
        raise Exception('\n'.join(msg))


def read_file(file_full_path, mode='r'):
    """
    从文件读取内容
    :param file_full_path: 文件全路径
    :param mode: 读取模式
    :return: string 文件内容
    """
    content = None
    try:
        with open(file_full_path, mode, encoding="UTF-8") as reader:
            content = reader.read()
            if content == "":
                content = None
            return content
    except FileNotFoundError:
        pass
    return None


def get_file_size(file_full_path):
    """
    获取文件大小
    :param file_full_path: 文件全路径
    :return:  文件大小
    """
    try:
        size = os.path.getsize(file_full_path)
        return size
    except Exception as err:
        print(err)

    return 0


def is_file_exist(file_full_path):
    """
    判断文件是否存在
    :return:  true为存在
    """
    return os.path.exists(file_full_path)


def delete_file(file_full_path):
    """
    文件删除
    :return:  
    """
    try:
        os.remove(file_full_path)
    except FileNotFoundError:
        print("file not found")
    except Exception as err:
        print(err)


def delete_folder(file_dir):
    """
    文件夹删除
    :return:  
    """
    if file_dir is None:
        return
    del_list = []
    try:
        del_list = os.listdir(file_dir)
        if del_list is None:
            return
        for f in del_list:
            file_path = os.path.join(file_dir, f)
            if os.path.isfile(file_path):
                os.remove(file_path)        
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path, True)
    except FileNotFoundError:
        print("file not found")
    

def get_mime_types(file_full_path):
    """
    获取mime types
    :return:  
    """
    m_type = None
    try:
        m_type = mimetypes.guess_type(file_full_path)[0]
    except FileNotFoundError:
        print("file not found")
    except Exception as err:
        print(err)
    return m_type

def create_dir(dir_path):
    """
    创建目录
    :return:  
    """
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)


def move_file(old_path, new_path):
    """
    文件移动
    :return:  
    """
    try:
        shutil.move(old_path, new_path)
    except FileNotFoundError:
        print("file not found")
    except Exception as err:
        print(err)


def copy_file(old_path, new_path):
    """
    文件拷贝
    :return:  
    """
    try:
        shutil.copyfile(old_path, new_path)
    except FileNotFoundError:
        print("file not found") 
    except Exception as err:
        print(err)


def get_filename(file_full_path):
    """
    获取文件名
    :return:  
    """
    return os.path.basename(file_full_path)
