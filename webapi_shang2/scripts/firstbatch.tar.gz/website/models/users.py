#coding=utf8
"""
File: user.py
Author: liujinhui
Time: 2019/11/20
"""
import json
import time
from typing import Optional, Awaitable
import file_util
from config import Config

class Users(object):
    """
    用户登录类
    """ 
    
    def __init__(self):
        """
        初始化
        :return:
        """ 
        pass

    def change_passwd(self, passwd):
        """
        修改密码
        :param passwd
        :return:
        """ 
        content = file_util.read_file(Config.user_path) 
        #文件不存在
        if content is None:
            new_data = {}
            new_data['username'] = "admin"
            new_data['password'] = passwd
            new_data['time_login'] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) 
            serialization=json.dumps(new_data, indent = 4).encode("utf-8")
            file_util.save_file(serialization, Config.user_path) 
        else:
            new_data = json.loads(content)
            new_data['password'] = passwd
            new_data['time_login'] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) 
            serialization=json.dumps(new_data, indent = 4).encode("utf-8")
            file_util.save_file(serialization, Config.user_path) 
        
    def check_user(self, username, passwd):  
        """
        校验用户及密码
        :param passwd
        :return:
        """ 
        ok = False
        if "admin" == username:    
            content = file_util.read_file(Config.user_path)
            if content is None:
                if "admin" == passwd:
                    new_data = {}
                    new_data['username'] = "admin"
                    new_data['password'] = passwd
                    new_data['time_login'] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) 
                    serialization=json.dumps(new_data, indent = 4).encode("utf-8")
                    file_util.save_file(serialization, Config.user_path) 
                    ok = True
            else:
                data_json = json.loads(content)
                old_passwd = data_json['password']
                if old_passwd == passwd:
                    ok = True
            
        return ok

    def get_login_info(self):
        """
        获取用户登录信息
        :param passwd
        :return:
        """ 
        content = file_util.read_file(Config.user_path) 
        #文件不存在
        if content is None:
            return None
        else:
            data_json = json.loads(content)
            login_info = {}
            login_info['username'] = data_json['username']
            login_info['time_login'] = data_json['time_login']
            return login_info

    def update_login_time(self):
        """
        更新登录时间
        :return:
        """ 
        content = file_util.read_file(Config.user_path) 
        if content is not None:
            login_info = json.loads(content)
            login_info['time_login'] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) 
            serialization=json.dumps(login_info, indent = 4).encode("utf-8")
            print(serialization)
            file_util.save_file(serialization, Config.user_path) 


    


    
            


        
        



   



