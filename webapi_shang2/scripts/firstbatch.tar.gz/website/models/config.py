#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
File: config.py
Author: liujinhui
Time: 2019/11/18
"""
import os
import traceback
import mimetypes
from settings import folder_web_cache

class Config(object):
    """
        config json path
    """
    user_path = os.path.normpath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..', folder_web_cache, 'users.json'))
    model_path = os.path.normpath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..', folder_web_cache, 'models.json'))
    collection_path = os.path.normpath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..', folder_web_cache, 'collections.json')) 
    camera_path = os.path.normpath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..', folder_web_cache, 'cameras.json')) 
    camera_setting_path = os.path.normpath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..', folder_web_cache, 'cameras_setting.json')) 
    camera_status_path = os.path.normpath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..', folder_web_cache, 'cameras_status.json')) 
    def __init__(self):
        """
        constructor
        """
        pass

