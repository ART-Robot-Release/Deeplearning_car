# coding=utf8
"""
   ipaddress Model support
"""
__author__ = 'quchunyu@baidu.com'

import os
import json
import file_util
from settings import folder_web_cache


class IPAddress(object):
    """
        IP Address Model support
    """
    def __init__(self):
        """
        constructor
        """
        self.ipaddress_path = os.path.normpath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), '../..', folder_web_cache, 'ipaddress.json'))
        pass

    @staticmethod
    def byteify(strings):
        """
        byteify
        :param strings: byteify strings
        :return: byteified strings
        """
        if isinstance(strings, dict):
            return {IPAddress.byteify(key): IPAddress.byteify(value) for key, value in strings.items()}
        elif isinstance(strings, list):
            return [IPAddress.byteify(element) for element in strings]
        elif isinstance(strings, str):
            return strings.encode('utf-8')
        else:
            return strings

    def read_interfaces_ip(self):
        """
        read_interfaces_ip
        :param arguments: parameters
        :return: dict object
        """
        file_path = "/etc/network/interfaces"
        address_ip = None
        with open(file_path, "r", encoding="utf-8") as f1:
            for line in f1:
                pos = line.find("address")
                if pos >= 0:
                    length = len(line)
                    address_ip = line[pos + 8:length].strip()
                    print("address_ip is:")
                    print(address_ip)
                    break
        return address_ip
                

    def get(self):
        """
        get
        :return: get the IP
        """
        if file_util.is_file_exist(self.ipaddress_path):
            with open(self.ipaddress_path) as f:
                return json.loads(f.read())
        else:
            print("ip obj 0000")
            address_ip = self.read_interfaces_ip()
            ip_obj = {}
            ip_obj['ip_address'] = address_ip
            self.set(ip_obj)
            print("ip obj is:")
            print(ip_obj)
            return ip_obj

    def set(self, ip):
        """
        save ip to file
        :param ip: ip address
        :return: True or False
        """
        with open(self.ipaddress_path, 'wb') as f:
            f.write(json.dumps(ip, sort_keys=True, indent=4).encode("utf-8"))



