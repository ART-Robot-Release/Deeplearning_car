#coding=utf8
"""
File: collecters.py
Author: liujinhui
Time: 2019/11/04
"""
import json
from typing import Optional, Awaitable
import file_util
from cameras import Cameras
from config import Config

class Collections(object):
    """
    采集类
    """ 
    def __init__(self):
        """
        初始化
        :return:
        """ 
        pass

    def collection_list(self):
        """
        采集列表
        :return:
        """ 
        content = file_util.read_file(Config.collection_path) 
        if content is None:
            return None
        content_json = json.loads(content)
        coll_arr = content_json['collections']
        if len(coll_arr):
            new_arr = []
            mgr = Cameras()
            for jt in coll_arr:
                jt['device'] = mgr.get_device_name(jt['device_id'])
                new_jt = {}
                new_jt['id'] = jt['id']
                new_jt['name'] = jt['name']
                new_jt['device_id'] = jt['device_id']
                new_jt['device'] = jt['device']
                new_jt['enable'] = jt['enable']
                new_jt['seconds'] = jt['seconds']
                new_jt['frames'] = jt['frames']
                new_jt['path'] = jt['path']
                new_jt['tf'] = jt['tf']
                new_jt['time'] = jt['time']
                new_arr.append(new_jt)
            if len(new_arr):
                data = {"collections":new_arr}
                return json.dumps(data)
            else:
                return None
        else:
            return None
        
        
    def get_collection(self, s_id):  
        """
        获取采集任务
        :param s_id, id
        :return:
        """ 
        content = file_util.read_file(Config.collection_path)
        if content is None:
            return content
        else:
            data_json = json.loads(content)
            collection_list = data_json['collections']
            new_jt = {}
            mgr = Cameras()
            exist = False
            for jt in collection_list:
                if int(s_id) == int(jt['id']):
                    new_jt['id'] = jt['id']
                    new_jt['name'] = jt['name']
                    new_jt['device_id'] = jt['device_id']
                    new_jt['device'] = mgr.get_device_name(jt['device_id'])
                    new_jt['enable'] = jt['enable']
                    new_jt['seconds'] = jt['seconds']
                    new_jt['frames'] = jt['frames']
                    new_jt['path'] = jt['path']
                    new_jt['tf'] = jt['tf']
                    new_jt['time'] = jt['time']
                    exist = True
                    break
            if exist:
                return new_jt
            else:
                return None

    def put_collection(self, new_data, s_id):
        """
        更新采集任务
        : new_data 新采集任务内容
        :param s_id, id
        :return:
        """
        content = file_util.read_file(Config.collection_path)
        if content is None:
            return content
        else:
            data_json = json.loads(content)
            collection_list = data_json['collections']
            if s_id.isdigit():
                arr =[]
                for it in collection_list:
                    if int(s_id) == int(it['id']):
                        new_data_json = json.loads(new_data)
                        tmp_json = {}
                        tmp_json['id'] = int(s_id)
                        tmp_json['name'] = new_data_json['name']
                        tmp_json['device_id'] = new_data_json['device_id']
                        tmp_json['enable'] = new_data_json['enable']
                        tmp_json['seconds'] = new_data_json['seconds']
                        tmp_json['frames'] = new_data_json['frames']
                        tmp_json['path'] = new_data_json['path']
                        tmp_json['tf'] = new_data_json['tf']
                        tmp_json['time'] = new_data_json['time']
                        arr.append(tmp_json)
                    else:
                        arr.append(it)
                       
                content_json = {"collections":arr}
                serialization = json.dumps(content_json, indent = 4).encode("utf-8")
                file_util.save_file(serialization, Config.collection_path) 
                return new_data
            else:
                return None
        return None

    def patch_collection(self, new_data, s_id):
        """
        更新采集任务
        : new_data 新采集任务内容
        :param s_id, id
        :return:
        """
        content = file_util.read_file(Config.collection_path)
        if content is None:
            return content
        else:
            data_json = json.loads(content)
            collection_list = data_json['collections']
            new_data_json = json.loads(new_data)
            if s_id.isdigit():
                arr =[]
                for it in collection_list:
                    if int(s_id) == int(it['id']):   
                        tmp_json = {}
                        tmp_json['id'] = int(s_id)
                        if "name" not in new_data_json:
                            tmp_json['name'] = it['name']
                        else:
                            tmp_json['name'] = new_data_json['name']
                        if "device_id" not in new_data_json:
                            tmp_json['device_id'] = it['device_id']
                        else:
                            tmp_json['device_id'] = new_data_json['device_id']

                        if "enable" not in new_data_json:
                            tmp_json['enable'] = it['enable']
                        else:
                            tmp_json['enable'] = new_data_json['enable']
                        if "seconds" not in new_data_json:
                            tmp_json['seconds'] = it['seconds']
                        else:
                            tmp_json['seconds'] = new_data_json['seconds']

                        if "frames" not in new_data_json:
                            tmp_json['frames'] = it['frames']
                        else:
                            tmp_json['frames'] = new_data_json['frames']

                        if "path" not in new_data_json:
                            tmp_json['path'] = it['path']
                        else:
                            tmp_json['path'] = new_data_json['path']

                        if "tf" not in new_data_json:
                            tmp_json['tf'] = it['tf']
                        else:
                            tmp_json['tf'] = new_data_json['tf']

                        if "time" not in new_data_json:
                            tmp_json['time'] = it['time']
                        else:
                            tmp_json['time'] = new_data_json['time']
                                         
                        arr.append(tmp_json)
                    else:
                        arr.append(it)
                       
                content_json = {"collections":arr}
                serialization=json.dumps(content_json, indent = 4).encode("utf-8")
                file_util.save_file(serialization, Config.collection_path) 
                return new_data_json
            else:
                return None
        return None

    def delete_collection(self, s_id):
        """
        删除采集任务
        :param s_id, id
        :return:
        """
        content = file_util.read_file(Config.collection_path)
        if content is None:
            return content
        else:
            data_json = json.loads(content)
            collection_list = data_json['collections']
            new_data_json = []
            if s_id.isdigit():
                arr =[]
                for it in collection_list:
                    if int(s_id) == int(it['id']):                        
                        new_data_json = it
                    else:
                        arr.append(it)
                       
                content_json = {"collections":arr}
                serialization=json.dumps(content_json, indent = 4).encode("utf-8")
                file_util.save_file(serialization, Config.collection_path) 
                return new_data_json
            else:
                return None
        return None

    def check_id_exist(self, s_id):
        """
        判断id是否存在
        :param s_id, id
        :return:
        """
        res = False
        content = file_util.read_file(Config.collection_path)
        if content is None:
            return res
        else:
            data_json = json.loads(content)
            collection_list = data_json['collections']
            for it in collection_list:
                if int(s_id) == int(it['id']):
                    res = True
            return res

    def gen_collection_id(self, content):
        """
        获取采集任务id
        :param content, 内容
        :return:
        """
        arr =[]
        for it in content:
            id = int(it['id'])
            arr.append(id)
        index = 0
        while index in arr:
            index += 1       
        return index

    def check_item(self, content):
        """
        判断是否存在
        :param content, 内容
        :return:
        """
        res = False
        if "name" not in content:
                 res = False
        else:
            res = True
        return res

    def create_collection(self, json_data):
            """
            创建采集任务
            :param json_data, 内容
            :return:
            """
            content = file_util.read_file(Config.collection_path)
            
            id = 0
            data_json = {} 
            if content is None:                             
                data_json['id'] = id
                data_json['name'] = json_data['name']
                data_json['device_id'] = json_data['device_id']
                data_json['enable'] = json_data['enable']
                data_json['seconds'] = json_data['seconds']
                data_json['frames'] = json_data['frames']
                data_json['path'] = json_data['path']
                data_json['tf'] = json_data['tf']
                data_json['time'] = json_data['time']
                json_arr = []
                json_arr.append(data_json)
                colls_content = {"collections": json_arr}
                serialization=json.dumps(colls_content, indent = 4).encode("utf-8")
                file_util.save_file(serialization, Config.collection_path) 
            else:
                content_json = json.loads(content)
                arr = content_json['collections']
                id = self.gen_collection_id(arr)  
                data_json['id'] = id  
                data_json['name'] = json_data['name']
                data_json['device_id'] = json_data['device_id']
                data_json['enable'] = json_data['enable']
                data_json['seconds'] = json_data['seconds']
                data_json['frames'] = json_data['frames']
                data_json['path'] = json_data['path']
                data_json['tf'] = json_data['tf']
                data_json['time'] = json_data['time']
                json_arr = []
                for jt in arr:
                    if isinstance(jt, dict):
                        json_arr.append(jt)
                    
                json_arr.append(data_json)
                colls_content = {"collections": json_arr}
                serialization=json.dumps(colls_content, indent = 4).encode("utf-8")
                file_util.save_file(serialization, Config.collection_path)   
                  
            return id


    
            


        
        



   



