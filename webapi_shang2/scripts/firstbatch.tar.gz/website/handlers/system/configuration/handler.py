# -*- coding: utf-8 -*-
"""
    SystemConfigurationHandler
"""
__author__ = 'quchunyu@baidu.com'

import os
import sys

import time
from datetime import datetime
import json
import traceback
import copy
import socket

from typing import Optional, Awaitable, Any
from datetime import datetime

import tornado.web
import tornado.gen

from framework.request_handler import RequestHandler

from ipaddress import IPAddress


def is_valid_ipv4_address(address):
    try:
        socket.inet_pton(socket.AF_INET, address)
    except AttributeError:
        try:
            socket.inet_aton(address)
        except socket.error:
            return False
        return address.count('.') == 3
    except socket.error:
        return False

    return True


def is_valid_datetime(time_string):
    try:
        datetime.strptime(time_string, '%Y-%m-%d %H:%M:%S')
    except ValueError:
        return False
    return True


class SystemConfigurationHandler(RequestHandler):
    def data_received(self, chunk: bytes) -> Optional[Awaitable[None]]:
        pass

    @tornado.gen.coroutine
    def get(self):
        if super().check_login() is False:
            return
        response = {
            "ip_address": IPAddress().get()['ip_address'],    # self.request.remote_ip,
            "system_time": datetime.now()
        }
        self.write_response(response)

    @tornado.gen.coroutine
    def patch(self):
        if super().check_login() is False:
            return
        #parameter = self.get_parameter()
        post_data = self.request.body.decode('utf-8') 
        if not post_data:
            self.set_status(204)
            return
        parameter = json.loads(post_data)
        print(parameter)

        if 'ip_address' in parameter:
            flag_ip = is_valid_ipv4_address(parameter['ip_address'])
            if flag_ip:
                ip = copy.deepcopy(parameter)
                del ip['system_time']
                IPAddress().set(ip)
                print(parameter['ip_address'])
                self.pipe.set_ip(parameter['ip_address'])
            else:
                parameter['msg_ip_address'] = 'Wrong IP address!'
                self.set_status(409)

        if 'system_time' in parameter:
            flag_datetime = is_valid_datetime(parameter['system_time'])
            if flag_datetime:
                print(parameter['system_time'])
                #self.pipe.set_time(parameter['system_time'])
                new_time_str = parameter['system_time']
                new_time = datetime.strptime(new_time_str, '%Y-%m-%d %H:%M:%S')
                str_date_command = 'date -s "%u-%02u-%02u %02u:%02u:%02u"' % \
                       (new_time.year, new_time.month, new_time.day, new_time.hour, new_time.minute, new_time.second)
                print('\t', str_date_command)
                os.system(str_date_command)
            else:
                parameter['msg_system_time'] = 'Wrong datetime!'
                self.set_status(409)

        self.write_response(parameter)
