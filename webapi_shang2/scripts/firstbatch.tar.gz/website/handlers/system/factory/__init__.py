# -*- coding: utf-8 -*-
"""
    system.factory Module
"""
__author__ = 'quchunyu@baidu.com'
