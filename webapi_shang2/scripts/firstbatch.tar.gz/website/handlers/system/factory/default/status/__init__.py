# -*- coding: utf-8 -*-
"""
    system.factory.default.status Module
"""
__author__ = 'quchunyu@baidu.com'
