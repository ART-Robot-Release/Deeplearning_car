# -*- coding: utf-8 -*-
"""
    SystemFactoryDefaultStatusHandler
"""
__author__ = 'quchunyu@baidu.com'

import os
import sys

import json
import traceback
import copy

from typing import Optional, Awaitable, Any
from datetime import datetime

import tornado.web
import tornado.gen

from framework.request_handler import RequestHandler


class SystemFactoryDefaultStatusHandler(RequestHandler):
    """
    SystemFactoryDefaultStatusHandler
    """
    def data_received(self, chunk: bytes) -> Optional[Awaitable[None]]:
        """
        data_received
        :param chunk:
        :return:
        """
        pass

    @tornado.gen.coroutine
    def get(self):
        """
        get
        :return: None
        """
        if super().check_login() is False:
            return
        response = {}
        status = 1
        if self.pipe.factory_default_status == 1:
       # if status==1 :
            response = {
                'status': 1,
                'message': 'setting factory default is working.'
            }
        else:
            response = {
                'status': 0,
                'message': 'setting factory default is done.'
            }

        self.write_response(response)

