# -*- coding: utf-8 -*-
"""
    SystemFactoryDefaultHandler
"""
__author__ = 'quchunyu@baidu.com'

import os
import sys

import json
import traceback
import copy

from typing import Optional, Awaitable, Any
from datetime import datetime

import tornado.web
import tornado.gen

from framework.request_handler import RequestHandler


class SystemFactoryDefaultHandler(RequestHandler):
    """
    SystemFactoryDefaultHandler
    """
    def data_received(self, chunk: bytes) -> Optional[Awaitable[None]]:
        """
        data_received
        :param chunk:
        :return:
        """
        pass

    @tornado.gen.coroutine
    def post(self):
        """
        post
        :return: None
        """
        response = {}

        status = self.pipe.factory_default()
        #status = 1
        if status == 1:
            self.set_header("Location", "api/system/factory/default/status")
            self.set_status(201)
        else:
            self.clear()
            self.set_status(509)

        self.write_response(response)

