# -*- coding: utf-8 -*-
"""
    system.restart.status Module
"""
__author__ = 'quchunyu@baidu.com'
