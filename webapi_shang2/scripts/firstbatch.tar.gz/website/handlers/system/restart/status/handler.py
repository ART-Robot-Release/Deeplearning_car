# -*- coding: utf-8 -*-
"""
    SystemRestartStatusHandler
"""
__author__ = 'quchunyu@baidu.com'

import os
import sys

import json
import traceback
import copy

from typing import Optional, Awaitable, Any
from datetime import datetime

import tornado.web
import tornado.gen

from framework.request_handler import RequestHandler


class SystemRestartStatusHandler(RequestHandler):
    """
    SystemRestartStatusHandler
    """
    def data_received(self, chunk: bytes) -> Optional[Awaitable[None]]:
        """
        data_received
        :param chunk:
        :return:
        """
        pass

    @tornado.gen.coroutine
    def get(self):
        """
        get
        :return: None
        """
        if super().check_login() is False:
            return
        response = {}
        if self.pipe.restart_status == 1:
        #status = 1
        #if status == 1:
            response = {
                'status': 1,
                'message': 'System restarting is working, and you should re-connect ME later.'
            }
        else:
            response = {
                'status': 0,
                'message': 'System restarting is done, and it may not work.'
            }

        self.write_response(response)

