# coding=utf8
from typing import Optional, Awaitable, Any

__author__ = 'liujinhui@baidu.com'

import os
import sys

import time
import json
import traceback

from datetime import datetime

import tornado.web
import tornado.gen


from framework.request_handler import RequestHandler
from cameras import Cameras

#摄像头列表
class CamerasHandler(RequestHandler):
    def data_received(self, chunk: bytes) -> Optional[Awaitable[None]]:
        pass

    @tornado.gen.coroutine
    def get(self):
        print("CamerasHandler aaaa")
        if super().check_login() is False:
            print("CamerasHandler 000")
            return
        mgr = Cameras()
        cameras = mgr.cameras_list()
        no_arr = {'cameras':[]}
        if cameras is None:
            self.write_response(no_arr)
        else:
            cameras_json = json.loads(cameras)
            arr = cameras_json['cameras']
            if len(arr):
                self.write_response(cameras_json)
            else:
                self.write_response(no_arr)
            
#摄像头管理          
class CameraHandler(RequestHandler):
    def data_received(self, chunk: bytes) -> Optional[Awaitable[None]]:
        pass

    @tornado.gen.coroutine
    def get(self, id):
        if super().check_login() is False:
            return
        mgr = Cameras()
        camera = mgr.get_camera(id)
        if camera is None:
            self.set_status(404)
        else:
            self.write_response(camera)
       
    @tornado.gen.coroutine
    def post(self):
        if super().check_login() is False:
            return
        post_data = self.request.body.decode('utf-8') 
        if  not post_data :
            self.set_status(404)
        else:
            #post_data = self.request.body.decode('utf-8')         
            json_data = json.loads(post_data)
            mgr = Cameras()
            exist = mgr.check_item(json_data)
            
            s_id = mgr.create_camera(json_data)
            self.set_status(201)
            host_ip = self.request.host
            s_header = "http://" + str(host_ip) + "/api/device/camera/" + str(s_id)
            self.set_header("Location", s_header)

    @tornado.gen.coroutine
    def put(self, id):
        if super().check_login() is False:
            return
        post_data = self.request.body.decode('utf-8') 
        if not post_data:
            self.set_status(204)
        else:        
            mgr = Cameras()
            res = mgr.check_id_exist(id)
            if not res:
                self.set_status(404)
            else:
                content = mgr.put_camera(post_data,id)
                content_json = json.loads(content)
                self.write_response(content_json)
     
    @tornado.gen.coroutine               
    def patch(self, id):
        if super().check_login() is False:
            return
        post_data = self.request.body.decode('utf-8') 
        if not post_data:
            self.set_status(204)
        else:      
            mgr = Cameras()
            res = mgr.check_id_exist(id)
            if not res:
                self.set_status(404)
            else:
                content = mgr.patch_camera(post_data,id)
                if content is None:
                    self.set_status(404)
                else:
                    self.write_response(content)
    
    @tornado.gen.coroutine
    def delete(self, id): 
        if super().check_login() is False:
            return   
        mgr = Cameras()
        res = mgr.check_id_exist(id)
        if not res:
            self.set_status(404)
        else:
            content = mgr.delete_camera(id)
            if content is None:
                self.set_status(404)
            else:
                self.write_response(content)

#摄像头设备信息设置
class CameraSettinglHandler(RequestHandler):
    def data_received(self, chunk: bytes) -> Optional[Awaitable[None]]:
        pass

    @tornado.gen.coroutine
    def get(self, id):
        if super().check_login() is False:
            return
        mgr = Cameras()
        setting = mgr.get_camera_setting(id)
        if setting is None:
            self.set_status(404)
        else:
            self.write_response(setting)
      
    @tornado.gen.coroutine 
    def put(self, id):
        if super().check_login() is False:
            return
        post_data = self.request.body.decode('utf-8') 
        if not post_data:
            self.set_status(204)
        else:        
            mgr = Cameras()
            res = mgr.check_id_exist(id)
            if not res:
                self.set_status(404)
            else:
                content = mgr.create_camera_setting(post_data,id)
                if content is None:
                    self.set_status(404)
                else:
                    content_json = json.loads(content)   
                    self.write_response(content_json)

#摄像头监控查看
class CameraMonitorHandler(RequestHandler):
    def data_received(self, chunk: bytes) -> Optional[Awaitable[None]]:
        pass

    @tornado.gen.coroutine
    def get(self, id):
        if super().check_login() is False:
            return
        mgr = Cameras()
        host_ip = self.request.host
        monitor = mgr.get_camera_monitor(id, host_ip)
        if monitor is None:
            self.set_status(404)
        else:
            self.write_response(monitor)

#摄像头监控状态获取与设置
class CameraStatusHandler(RequestHandler):
    def data_received(self, chunk: bytes) -> Optional[Awaitable[None]]:
        pass

    @tornado.gen.coroutine
    def get(self, id):
        if super().check_login() is False:
            return
        mgr = Cameras()
        status = mgr.get_camera_status(id)
        if status is None:
            self.set_status(404)
        else:
            self.write_response(status)

    @tornado.gen.coroutine
    def post(self, id):
        if super().check_login() is False:
            return
        post_data = self.request.body.decode('utf-8')
        if  not post_data :
            self.set_status(404)
        else: 
            mgr = Cameras()
            status = mgr.set_camera_status(id, post_data)
            if status is None:
                self.set_status(404)
            else:
                self.write_response(status)

#监测图片下载
class MonitorImageHandler(tornado.web.RequestHandler):
    def data_received(self, chunk: bytes) -> Optional[Awaitable[None]]:
        pass

    @tornado.gen.coroutine
    def get(self, name):
        
        self.set_header ('Content-Type', 'application/octet-stream')
        buf_size = 4096
        filename = name
        if filename == "default.jpg":
            filename = os.getcwd() + "/attatch/default.jpg"
            pass
        else:
            root_path = os.path.normpath(
                    os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../../..', 'processes/results'))
            #filename = root_path + "/" + name
            tmp = name.split('.')
            camera_id = tmp[0].split('/')[0]
            model_id = tmp[0].split('/')[1]
            mgr = Cameras()
            filename = mgr.get_pre_image_path(root_path, camera_id, model_id)
            #mgr.copy_image_from_aiworker(camera_id, model_id, False)
        #filename = None
        if filename is None:
            filename = os.getcwd() + "/attatch/default.jpg"
        
        with open(filename, 'rb') as f:
            while True:
                data = f.read(buf_size)
                if not data:
                    break
                self.write(data)
        self.finish()

        



       
                    



               

    


