# coding=utf8
from typing import Optional, Awaitable, Any

__author__ = 'liujinhui@baidu.com'

import os
import sys

import time
import json
import traceback

from datetime import datetime

import tornado.web
import tornado.gen


from framework.request_handler import RequestHandler
from models import Models
import file_util
from settings import folder_web_cache


class ModelsHandler(RequestHandler):
    def data_received(self, chunk: bytes) -> Optional[Awaitable[None]]:
        pass

    @tornado.gen.coroutine
    def get(self):
        if super().check_login() is False:
            return
        
        mgr = Models()
        models = mgr.models_list()
        no_arr = {'models':[]}
        if models is None:
            self.write_response(no_arr)
        else:
            models_json = json.loads(models)
            arr = models_json['models']
            if len(arr):
                self.write_response(models_json)
            else:
                self.write_response(no_arr)
            
            
class ModelHandler(RequestHandler):
    def data_received(self, chunk: bytes) -> Optional[Awaitable[None]]:
        pass

    @tornado.gen.coroutine
    def get(self, id):
        if super().check_login() is False:
            return
        mgr = Models()
        model = mgr.get_model(id)
        if model is None:
            self.set_status(404)
        else:
            self.write_response(model)
        
    @tornado.gen.coroutine 
    def post(self):
        if super().check_login() is False:
            return
        post_data = self.request.body.decode('utf-8') 
        if  not post_data :
            self.set_status(404)
        else:        
            json_data = json.loads(post_data)
            mgr = Models()
            exist = mgr.check_item(json_data)
            
            s_id = mgr.create_model(json_data)
            self.set_status(201)
            host_ip = self.request.host
            s_header = "http://" + str(host_ip) + "/api/model/" + str(s_id)
            self.set_header("Location", s_header)

    @tornado.gen.coroutine
    def put(self, id):
        if super().check_login() is False:
            return
        post_data = self.request.body.decode('utf-8') 
        if not post_data:
            self.set_status(204)
        else:        
            mgr = Models()
            res = mgr.check_id_exist(id)
            if not res:
                self.set_status(404)
            else:
                content = mgr.put_model(post_data,id)
                content_json = json.loads(content)
                self.write_response(content_json)
       
    @tornado.gen.coroutine             
    def patch(self, id):
        if super().check_login() is False:
            return
        post_data = self.request.body.decode('utf-8') 
        if not post_data:
            self.set_status(204)
        else:      
            mgr = Models()
            res = mgr.check_id_exist(id)
            if not res:
                self.set_status(404)
            else:
                content = mgr.patch_model(post_data,id)
                if content is None:
                    self.set_status(404)
                else:
                    self.write_response(content)
    
    @tornado.gen.coroutine
    def delete(self, id):  
        if super().check_login() is False:
            return   
        mgr = Models()
        res = mgr.check_id_exist(id)
        if not res:
            self.set_status(404)
        else:
            content = mgr.delete_model(id)
            if content is None:
                self.set_status(404)
            else:
                self.write_response(content)

class UploadHandler(tornado.web.RequestHandler):
    
    @tornado.gen.coroutine
    def post(self):   
        file_metas = self.request.files.get('files[]', None)  # 提取表单中‘name’为‘file’的文件元数据
        ret_json={'files':''}
        if not file_metas:      
            self.set_status(404)
            self.set_header("Content-Type", "application/json; charset=UTF-8")
            self.set_header("Access-Control-Allow-Origin", "*")
            self.set_header("Access-Control-Allow-Method", "GET")
            self.finish()
            return

        json_arr =[]
        host_ip = self.request.host
     
        mgr = Models()
        tmp_dir = mgr.gen_model_tmp_path()
        for meta in file_metas:
            filename = meta['filename']
            content_type =meta['content_type']
            file_path = os.path.normpath(
            os.path.join(tmp_dir, filename))
            with open(file_path, 'wb') as up:
                up.write(meta['body'])

            is_valid = mgr.check_upload_model(file_path)
            if is_valid:
                file_size = file_util.get_file_size(file_path)
                file_data = {}
                file_data['name'] = filename
                #file_data['url'] = "http://"+ host_ip + "/api/model/package/uploaded/" + filename
                file_data['url'] = "/api/model/package/uploaded/" + filename
                file_data['type'] = content_type
                file_data['size'] = file_size 
                json_arr.append(file_data)
            else:
                pass
            

        if len(json_arr)>0:
            ret_json['files'] = json_arr  
            response={}
            response['errno'] = 0
            response['message'] ='success'
            response['data'] = ret_json
            self.write(json.dumps(response, indent = 4))
            #self.write(json.dumps(ret_json, indent = 4))
        else:
            response={}
            response['errno'] = 1006
            response['message'] ='model file invalid'
            self.write(json.dumps(response, indent = 4))
                
        self.set_header("Content-Type", "application/json; charset=UTF-8")
        self.set_header("Access-Control-Allow-Origin", "*")
        self.set_header("Access-Control-Allow-Method", "GET")
        self.finish()

class UploadedHandler(tornado.web.RequestHandler):

    @tornado.gen.coroutine
    def delete(self, name):  
        req_uri = self.request.uri
        pos = req_uri.find('uploaded')
        uri_len = len(req_uri)
        if pos<0 :
            self.set_status(404)
            self.set_header("Content-Type", "application/json; charset=UTF-8")
            self.set_header("Access-Control-Allow-Origin", "*")
            self.set_header("Access-Control-Allow-Method", "GET")
            self.finish()
            return
        sub_uri = req_uri[pos+9:uri_len]
             
        file_data = {}
        file_full_path = ""
        #查找模型id编号:
        id_pos = sub_uri.find('/')
        model_id = -1
        if id_pos>0 :     
            model_id = sub_uri[0:id_pos]
            name = file_util.get_filename(sub_uri)
            file_data['name'] = name
            file_data['file'] = "/api/model/package/uploaded/" + sub_uri
            path = 'repository/models/'+ model_id
            file_full_path = os.path.normpath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../..', path, name))
        else:
            file_data['name'] = name
            file_data['file'] = "/api/model/package/uploaded/" + name
            file_full_path = os.path.normpath(
            os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../..', 'repository/tmp-models', name))
    
        if file_util.is_file_exist(file_full_path):          
            file_type = file_util.get_mime_types(file_full_path)
            file_data['type'] = file_type
            file_size = file_util.get_file_size(file_full_path)
            file_data['size'] = file_size
            file_util.delete_file(file_full_path)
            mgr = Models()
            if int(model_id) >= 0:
                mgr.delete_model_file_json(model_id)
            self.write(json.dumps(file_data, indent = 4 ))
            self.set_header("Content-Type", "application/json; charset=UTF-8")
            self.set_header("Access-Control-Allow-Origin", "*")
            self.set_header("Access-Control-Allow-Method", "GET")
            self.finish()
        else:
            self.set_status(404)
            self.set_header("Content-Type", "application/json; charset=UTF-8")
            self.set_header("Access-Control-Allow-Origin", "*")
            self.set_header("Access-Control-Allow-Method", "GET")
            self.finish()

#模型示例文件下载
class ModelExampleHandler(tornado.web.RequestHandler):
    def data_received(self, chunk: bytes) -> Optional[Awaitable[None]]:
        pass

    @tornado.gen.coroutine
    def get(self, name):
        """
        下载模型示例文件
        :name 文件名
        :return: 
        """ 
        print("in model ModelExampleHandler")
        self.set_header ('Content-Type', 'application/octet-stream')
        buf_size = 4096
        filename = name
        if filename == "model.tar.gz":
            filepath = os.getcwd() + "/attatch/model.tar.gz"
            with open(filepath, 'rb') as f:
                while True:
                    data = f.read(buf_size)
                    if not data:
                        break
                    self.write(data)
            self.finish()
        else:
            self.set_status(404)
            self.set_header("Content-Type", "application/json; charset=UTF-8")
            self.set_header("Access-Control-Allow-Origin", "*")
            self.set_header("Access-Control-Allow-Method", "GET")
            self.finish()
        
        


    

               

    


