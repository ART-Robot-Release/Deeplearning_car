# coding=utf8
from typing import Optional, Awaitable, Any

__author__ = 'liujinhui@baidu.com'

import os
import sys

import time
import json
import traceback

from datetime import datetime
import tornado.web
import tornado.gen

from framework.request_handler import RequestHandler
from collectors import Collections

class CollectionsHandler(RequestHandler):
    def data_received(self, chunk: bytes) -> Optional[Awaitable[None]]:
        pass

    @tornado.gen.coroutine
    def get(self):
        if super().check_login() is False:
            return
        mgr = Collections()
        colls = mgr.collection_list()
        no_arr = {'collections':[]}
        if colls is None:
            self.write_response(no_arr)
        else:
            colls_json = json.loads(colls)
            arr = colls_json['collections']
            if len(arr):
                self.write_response(colls_json)
            else:
                self.write_response(no_arr)

            
class CollectionHandler(RequestHandler):
    def data_received(self, chunk: bytes) -> Optional[Awaitable[None]]:
        pass

    @tornado.gen.coroutine
    def get(self, id):
        if super().check_login() is False:
            return
        mgr = Collections()
        coll = mgr.get_collection(id)
        if coll is None:
            self.set_status(404)
        else:
            self.write_response(coll)
        
    @tornado.gen.coroutine               
    def post(self):
        if super().check_login() is False:
            return
        post_data = self.request.body.decode('utf-8') 
        if  not post_data :
            self.set_status(404)
        else:       
            json_data = json.loads(post_data)
            mgr = Collections()
            exist = mgr.check_item(json_data)     
            s_id = mgr.create_collection(json_data)
            self.set_status(201)
            host_ip = self.request.host
            s_header = "http://" + str(host_ip) + "/api/task/collection/" + str(s_id)
            self.set_header("Location", s_header)

    @tornado.gen.coroutine
    def put(self, id):
        if super().check_login() is False:
            return
        post_data = self.request.body.decode('utf-8') 
        if not post_data:
            self.set_status(204)
        else:         
            mgr = Collections()
            res = mgr.check_id_exist(id)
            if not res:
                self.set_status(404)
            else:
                content = mgr.put_collection(post_data,id)
                content_json = json.loads(content)
                self.write_response(content_json)
       
    @tornado.gen.coroutine             
    def patch(self, id):
        if super().check_login() is False:
            return
        post_data = self.request.body.decode('utf-8') 
        if not post_data:
            self.set_status(204)
        else:     
            mgr = Collections()
            res = mgr.check_id_exist(id)
            if not res:
                self.set_status(404)
            else:
                content = mgr.patch_collection(post_data,id)
                if content is None:
                    self.set_status(404)
                else:
                    self.write_response(content)
    
    @tornado.gen.coroutine
    def delete(self, id):  
        if super().check_login() is False:
            return       
        mgr = Collections()
        res = mgr.check_id_exist(id)
        if not res:
            self.set_status(404)
        else:
            content = mgr.delete_collection(id)
            if content is None:
                self.set_status(404)
            else:
                self.write_response(content)
               

    


