# coding=utf8
"""
    LoginHandler
"""
from typing import Optional, Awaitable, Any

__author__ = 'liujinhui@baidu.com'

import os
import sys

import time
import json
import traceback

from datetime import datetime

import tornado.web
import tornado.gen


from framework.request_handler import RequestHandler
from users import Users
import file_util


class LoginHandler(RequestHandler):
    """
    LoginHandler
    """
    @tornado.gen.coroutine
    def get(self):
        """
        get
        """ 
        incorrect = self.get_secure_cookie("incorrect")
        result_info = {}
        result_info['errno'] = 1003
        result_info['message'] = "get login info fail"

        # login cout max
        if incorrect and int(incorrect) > 10:
            self.write(json.dumps(result_info, indent = 4))
            return
        if not self.current_user:
            #result_info['errno'] = 1005
            #result_info['message'] = "user not login"
            self.write(json.dumps(result_info, indent = 4))
            return
        mgr = Users()
        info = mgr.get_login_info()
        if info is None:
            self.write_response(result_info)        
        else:
            result_info['errno'] = 0
            result_info['message'] = "success"
            result_info['data'] = info
            self.write(json.dumps(result_info, indent = 4))
       
    @tornado.gen.coroutine
    def post(self):
        """
        post
        """ 
        result_info = {}
        result_info['errno'] = 1001
        result_info['message'] = "password error"
        incorrect = self.get_secure_cookie("incorrect")
        if incorrect and int(incorrect) > 10:
            self.write(json.dumps(result_info, indent = 4))
            return
        post_data = self.request.body.decode('utf-8') 
        if  not post_data:
            self.write(json.dumps(result_info, indent = 4))
        else:        
            json_data = json.loads(post_data)
            username = json_data['username']
            password = json_data['password']
            mgr = Users()
            ok = mgr.check_user(username, password)
            if ok:
                self.set_secure_cookie("user", username + password)
                self.set_secure_cookie("incorrect", "0")
                result_info['errno'] = 0
                result_info['message'] = "success"
                mgr.update_login_time()
                self.write(json.dumps(result_info, indent = 4))
            else:
                incorrect = self.get_secure_cookie("incorrect") or 0
                increased = str(int(incorrect)+1)
                self.set_secure_cookie("incorrect", increased)
                self.write(json.dumps(result_info, indent = 4))


class LogoutHandler(RequestHandler):
    """
    LogoutHandler
    """  
    @tornado.gen.coroutine 
    def post(self):
        """
        clear cookie
        """ 
        self.clear_cookie("user")
        result_info = {}
        result_info['errno'] = 0
        result_info['message'] = "success"
        self.write(json.dumps(result_info, indent = 4))


class ChangePasswordHandler(RequestHandler):
    """
    ChangePasswordHandler
    """ 
    @tornado.gen.coroutine   
    def post(self):
        """
        post
        return data
        """ 
        post_data = self.request.body.decode('utf-8') 
        result_info = {}
        result_info['errno'] = 1002
        result_info['message'] = "old password error"
        if  not post_data: 
            self.write(json.dumps(result_info, indent = 4))
        else:        
            json_data = json.loads(post_data)
            username = json_data['username']
            password = json_data['oldpassword']
            new_psw = json_data['newpassword']

            if username is None or password is None or new_psw is None:
                self.write(json.dumps(result_info, indent = 4))
                return
            if username == "admin":
                mgr = Users()
                ok = mgr.check_user(username, password)
                if ok:
                    mgr.change_passwd(new_psw)
                    self.clear_cookie("user")
                    result_info['errno'] = 0
                    result_info['message'] = "success"          
            self.write(json.dumps(result_info, indent = 4))

        
            



    

               

    


