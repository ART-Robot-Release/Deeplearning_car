#coding=utf8
"""
    web system routings
"""
__author__ = 'quchunyu@baidu.com'

import os
import sys

import time
import json
import traceback

import tornado.web
import tornado.gen

from index.handler import IndexHandler
from system.status.handler import SystemStatusHandler
from lanemarking.status.handler import LanemarkingStatusHandler
from lanemarking.packages.handler import LanemarkingPackagesHandler

# from login.handler import LoginHandler
# from login.handler import LogoutHandler
# from login.handler import ChangePasswordHandler
# from system.configuration.handler import SystemConfigurationHandler
# from system.factory.default.handler import SystemFactoryDefaultHandler
# from system.factory.default.status.handler import SystemFactoryDefaultStatusHandler
# from system.restart.handler import SystemRestartHandler
# from system.restart.status.handler import SystemRestartStatusHandler
# from model.handler import ModelsHandler
# from model.handler import ModelHandler
# from model.handler import UploadHandler
# from model.handler import UploadedHandler
# from model.handler import ModelExampleHandler
# from collection.handler import CollectionsHandler
# from collection.handler import CollectionHandler
# from device.camera.handler import CamerasHandler
# from device.camera.handler import CameraHandler
# from device.camera.handler import CameraSettinglHandler
# from device.camera.handler import CameraMonitorHandler
# from device.camera.handler import CameraStatusHandler
# from device.camera.handler import MonitorImageHandler

routings = [
    (r"/", IndexHandler, dict(params=None)),
    (r"/api/system/status", SystemStatusHandler, dict(params=None)),
    (r"/api/lanemarking/status", LanemarkingStatusHandler, dict(params=None)),
    (r"/api/lanemarking/packages/(.*)", LanemarkingPackagesHandler, dict(params=None)),
    # (r"/api/system/login", LoginHandler, dict(params=None)),
    # (r"/api/system/logout", LogoutHandler, dict(params=None)),
    # (r"/api/system/changepassword", ChangePasswordHandler, dict(params=None)),
    # (r"/api/system/configuration", SystemConfigurationHandler, dict(params=None)),
    # (r"/api/system/factory/default", SystemFactoryDefaultHandler, dict(params=None)),
    # (r"/api/system/factory/default/status", SystemFactoryDefaultStatusHandler, dict(params=None)),
    # (r"/api/system/restart", SystemRestartHandler, dict(params=None)),
    # (r"/api/system/restart/status", SystemRestartStatusHandler, dict(params=None)),
    # (r"/api/models", ModelsHandler, dict(params=None)),
    # (r"/api/model", ModelHandler, dict(params=None)),
    # (r"/api/model/([0-9]+)", ModelHandler, dict(params=None)),
    # (r"/api/task/collections", CollectionsHandler, dict(params=None)),
    # (r"/api/task/collection", CollectionHandler, dict(params=None)),
    # (r"/api/task/collection/([0-9]+)", CollectionHandler, dict(params=None)),
    # (r"/api/model/package/upload", UploadHandler),
    # (r"/api/model/package/uploaded/(.*)", UploadedHandler),
    # (r"/api/model/package/example/(.*)", ModelExampleHandler),
    # (r"/api/device/cameras", CamerasHandler, dict(params=None)),
    # (r"/api/device/camera", CameraHandler, dict(params=None)),
    # (r"/api/device/camera/([0-9]+)", CameraHandler, dict(params=None)),
    # (r"/api/device/camera/([0-9]+)/models", CameraSettinglHandler, dict(params=None)),
    # (r"/api/device/camera/result/monitor/([0-9]+)", CameraMonitorHandler, dict(params=None)),
    # (r"/api/device/camera/([0-9]+)/status", CameraStatusHandler, dict(params=None)),
    # (r"/api/monitoring/result/images/(.*)", MonitorImageHandler),
]

