#coding=utf8
__author__ = 'quchunyu@baidu.com'

debug = True
gzip = False

folder_web_cache = 'repository/web-caches'
folder_models_src_tar_path = 'repository/models'
folder_models_dst_tar_path = 'processes/models'

secrets = {
    # appkey: secret
    'frombrowser': 'e259d018f0c02951162e009ce512acc8'
}

