# -*- coding: utf-8 -*-
__author__ = 'quchunyu@baidu.com'

import logging
import os
import signal
import time
import subprocess

from tornado import ioloop
from tornado import web
from tornado.httpserver import HTTPServer

process_lanemarking = None


class Edgeboard(object):

    @classmethod
    def start_lanemarking(cls, speed, camera, downusb, location):
        global process_lanemarking

        obj_args = {
            # 'stdout': subprocess.PIPE,
        }
        print(process_lanemarking)

        if process_lanemarking is None:
            os.chdir('../scripts')
            process_lanemarking = subprocess.Popen(['python', 'lanemarking.py', str(speed), camera, downusb, location],
                                                   **obj_args)
            print('starting lanemarking ...')
            os.chdir('../website')
            return True

        return False

