# -*- coding: utf-8 -*-
__author__ = 'quchunyu@baidu.com'

"""
    provides global functional functions
"""
