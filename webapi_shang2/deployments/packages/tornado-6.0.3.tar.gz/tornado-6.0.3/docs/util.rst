``tornado.util`` --- General-purpose utilities
==============================================

.. testsetup::

   from tornado.util import *

.. automodule:: tornado.util
    :members:
